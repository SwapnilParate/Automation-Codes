import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name = "Swapnil";
		
		System.setProperty("webdriver.chrome.driver","D:\\Automation-Testing\\Codes\\DropDowms\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		driver.findElement(By.id("name")).sendKeys(name);
		driver.findElement(By.id("alertbtn")).click();
		String Text = driver.switchTo().alert().getText();
		System.out.println(Text);
		driver.switchTo().alert().accept();
		
		driver.findElement(By.id("name")).sendKeys(name);
		driver.findElement(By.id("confirmbtn")).click();
		String Text1 = driver.switchTo().alert().getText();
		System.out.println(Text1);
		driver.switchTo().alert().dismiss();
		
		


	}

}
