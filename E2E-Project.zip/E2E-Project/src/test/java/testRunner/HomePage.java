package testRunner;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Automation.LandingPage;
import resources.Base;

public class HomePage extends Base {
	
	public WebDriver driver;
	public static Logger log = LogManager.getLogger(Base.class.getName());
	@BeforeTest
	public void openBrowser () throws IOException {
		driver = initializeBrowser();
		log.info("Driver is initialized");
		driver.get(prop.getProperty("url"));
		log.info("URL is triggered");
		driver.manage().window().maximize();
	}
	
	@Test 
	public void validateHomePage () throws IOException {
		
		
		LandingPage lp = new LandingPage(driver);
		Assert.assertEquals(lp.validateText().getText(),"Sign in using your Yahoo account123");
		log.info("Validated headline of Yahoo page");
		Assert.assertTrue(lp.validateLoginButton().isDisplayed());
		log.info("Validated login button is presnt");
		Assert.assertTrue(lp.validatecreateAccount().isDisplayed());
		log.info("Validated create account button is presnt");
		
	}
	
	@AfterTest
	public void tearDown () {
		driver.close();
	}

	
}
