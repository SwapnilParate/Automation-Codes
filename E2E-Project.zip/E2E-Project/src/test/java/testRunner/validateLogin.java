package testRunner;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Automation.LoginPage;

import resources.Base;

public class validateLogin extends Base {

	public WebDriver driver;
	public static Logger log = LogManager.getLogger(Base.class.getName());

	@Test(dataProvider = "getData")
	public void login(String firstname, String lastname, String userid, String password, String birthyear)
			throws InterruptedException, IOException {

		driver = initializeBrowser();
		driver.get(prop.getProperty("url"));
		driver.manage().window().maximize();
		LoginPage rd = new LoginPage(driver);
		rd.createAccount().click();
		rd.firstName().sendKeys(firstname);
		rd.lastName().sendKeys(lastname);
		rd.userId().sendKeys(userid);
		rd.password().sendKeys(password);
		rd.birthYear().sendKeys(birthyear);
		rd.submit().click();
		
		log.info("Validated account is created");
		
		driver.close();

	}

	@DataProvider
	public Object[][] getData() {

		Object[][] data = new Object[2][5];

		// 1st data
		data[0][0] = "abcd";
		data[0][1] = "gefc";
		data[0][2] = "username";
		data[0][3] = "123456";
		data[0][4] = "1998";

		// 2nd data
		data[1][0] = "ABCD";
		data[1][1] = "GEDFR";
		data[1][2] = "password";
		data[1][3] = "45678";
		data[1][4] = "2003";

		return data;
	}

}
