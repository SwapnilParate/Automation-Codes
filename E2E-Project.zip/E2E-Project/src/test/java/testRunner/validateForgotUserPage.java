package testRunner;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Automation.ForgotUsernamePage;
import resources.Base;

public class validateForgotUserPage extends Base {
	
	public WebDriver driver;
	public static Logger log = LogManager.getLogger(Base.class.getName());
	@Test (dataProvider="getData")
	public void validateForgotUserPage (String phonenumner) throws IOException {
		
		driver = initializeBrowser();
		driver.get(prop.getProperty("url"));
		driver.manage().window().maximize();
		ForgotUsernamePage fp = new ForgotUsernamePage(driver);
		
		fp.forgotUsername().click();
		log.info("Validated forgot username is clicked properly");
		fp.userName().sendKeys(phonenumner);
		log.info("Validated phone numbers are send correctly");
		fp.continueButton().click();
		Assert.assertEquals(fp.validateErrorMsg().getText(),"Sorry, we don't recognise this phone number.");
		log.info("Validated error message is correct in forgot user page");
		driver.close();
	}

	@DataProvider
	public Object[] getData () {
		
		Object [] data = new Object [2];
		data [0] = "675378290837";
		data [1] = "975378290837";
		
		return data;
				
	}
}
