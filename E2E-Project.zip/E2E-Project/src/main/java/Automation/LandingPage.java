package Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPage {

	public WebDriver driver;

	private By signinText = By.xpath("//span[@class='challenge-desc signin-sub-title']");
	private By loginButton = By.id("login-signin");
	private By createAccount = By.id("createacc");
	

	public LandingPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement validateText() {
		return driver.findElement(signinText);
	}

	public WebElement validateLoginButton() {
		return driver.findElement(loginButton);
	}
	
	public WebElement validatecreateAccount() {
		return driver.findElement(createAccount);
	}
}
