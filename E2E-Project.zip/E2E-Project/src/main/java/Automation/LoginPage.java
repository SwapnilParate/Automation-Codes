package Automation;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class LoginPage {
	
	public WebDriver driver;
	
	private By createAccount = By.id("createacc");
	private By firstName = By.id("usernamereg-firstName");
	private By lastName = By.id("usernamereg-lastName");
	private By userId = By.id("usernamereg-userId");
	private By password = By.id("usernamereg-password");
	private By birthYear = By.id("usernamereg-birthYear");
	private By submit = By.id("reg-submit-button");

	public LoginPage(WebDriver driver) {
		
		this.driver=driver;
		
	}

	public WebElement createAccount()

	{
		return driver.findElement(createAccount);
	}

	public WebElement firstName()

	{
		return driver.findElement(firstName);
	}
	
	public WebElement lastName()

	{
		return driver.findElement(lastName);
	}
	
	public WebElement userId()

	{
		return driver.findElement(userId);
	}

	public WebElement password()

	{
		return driver.findElement(password);
	}
	
	public WebElement birthYear()

	{
		return driver.findElement(birthYear);
	}
	
	public WebElement submit()

	{
		return driver.findElement(submit);
	}
}
