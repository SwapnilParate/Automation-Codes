package Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ForgotUsernamePage {

	public WebDriver driver;

	private By forgotUsername = By.xpath("//a[@id='mbr-forgot-link']");
	private By userName = By.id("username");
	private By continueButton = By.xpath("//button[normalize-space()='Continue']");
	private By errorMsg = By.xpath("//div[@role='alert']");

	public ForgotUsernamePage(WebDriver driver) {

		this.driver = driver;
	}

	public WebElement forgotUsername() {

		return driver.findElement(forgotUsername);
	}

	public WebElement userName() {

		return driver.findElement(userName);
	}
	
	public WebElement continueButton() {

		return driver.findElement(continueButton);
	}

	public WebElement validateErrorMsg() {

		return driver.findElement(errorMsg);
	}
}
