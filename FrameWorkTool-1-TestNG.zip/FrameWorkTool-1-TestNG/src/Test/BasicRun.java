package Test;

import org.testng.annotations.Test;

public class BasicRun {

	@Test
	public void Demo () {
		
		System.out.println("Hello");
	}
	
	@Test
	public void Demo1 () {
		
		System.out.println("Bye");
	}
}
