package Test;

import org.testng.annotations.Test;

public class XMLRun {
	
	@Test
	public void Demo () {
		
		System.out.println("Good");
	}

}
