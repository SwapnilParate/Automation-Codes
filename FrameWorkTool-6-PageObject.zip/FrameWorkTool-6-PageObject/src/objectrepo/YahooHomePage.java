package objectrepo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class YahooHomePage {
	
	WebDriver driver;

	public YahooHomePage(WebDriver driver) {
		this.driver = driver;
	}

	By clickImgYahoo = By.xpath("//img[@class='logo ']");
	By searchBox = By.id("yschsp");
	By searchButton = By.xpath("//button[@type='submit']");
	
	public WebElement clickImgYahoo()

	{
		return driver.findElement(clickImgYahoo);
	}
	
	public WebElement searchBox()

	{
		return driver.findElement(searchBox);
	}

	public WebElement searchButton()

	{
		return driver.findElement(searchButton);
	}
}
