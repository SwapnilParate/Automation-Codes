package objectrepo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class YahooCreateAccountPage {

	WebDriver driver;

	public YahooCreateAccountPage(WebDriver driver) {
		this.driver = driver;
	}

	By createAccount = By.id("createacc");
	By firstName = By.id("usernamereg-firstName");
	By lastName = By.id("usernamereg-lastName");
	By userId = By.id("usernamereg-userId");
	By password = By.id("usernamereg-password");
	By birthYear = By.id("usernamereg-birthYear");
	By submit = By.id("reg-submit-button");

	public WebElement createAccount()

	{
		return driver.findElement(createAccount);
	}

	public WebElement firstName()

	{
		return driver.findElement(firstName);
	}
	
	public WebElement lastName()

	{
		return driver.findElement(lastName);
	}
	
	public WebElement userId()

	{
		return driver.findElement(userId);
	}

	public WebElement password()

	{
		return driver.findElement(password);
	}
	
	public WebElement birthYear()

	{
		return driver.findElement(birthYear);
	}
	
	public WebElement submit()

	{
		return driver.findElement(submit);
	}
}
