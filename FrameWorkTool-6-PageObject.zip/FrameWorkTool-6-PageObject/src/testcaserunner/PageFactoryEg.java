package testcaserunner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import pagefactory.YahooCreateAccountPageFactory;
import pagefactory.YahooHomePageFactory;

public class PageFactoryEg {

	@Test
	public void login() throws InterruptedException {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Swapnil\\eclipse-workspace\\FrameWorkTool-6-PageObject\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://login.yahoo.com/?.intl=in");
		driver.manage().window().maximize();
		YahooCreateAccountPageFactory rd = new YahooCreateAccountPageFactory (driver);
		YahooHomePageFactory yp = new YahooHomePageFactory (driver);
		
		rd.createAccount().click();
		rd.firstName().sendKeys("abcs");
		rd.lastName().sendKeys("abcd");
		rd.userId().sendKeys("asdfgh");
		rd.password().sendKeys("123456");
		rd.birthYear().sendKeys("2000");
		rd.submit().click();
		
		yp.clickImgYahoo().click();
		yp.searchBox().sendKeys("Samsung");
		yp.searchButton().click();
		
		driver.quit();
		

	}
}
