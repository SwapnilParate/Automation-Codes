package pagefactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class YahooCreateAccountPageFactory {

	WebDriver driver;

	public YahooCreateAccountPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="createacc")
	WebElement createAccount ;
	
	@FindBy(id="usernamereg-firstName")
	WebElement firstName ;
	
	@FindBy(id="usernamereg-lastName")
	WebElement lastName ;
	
	@FindBy(id="usernamereg-userId")
	WebElement userId ;
	
	@FindBy(id="usernamereg-password")
	WebElement password ;

	@FindBy(id="usernamereg-birthYear")
	WebElement birthYear ;
	
	@FindBy(id="reg-submit-button")
	WebElement submit ;


	public WebElement createAccount()

	{
		return createAccount;
	}

	public WebElement firstName()

	{
		return firstName;
	}
	
	public WebElement lastName()

	{
		return lastName;
	}
	
	public WebElement userId()

	{
		return userId;
	}

	public WebElement password()

	{
		return password;
	}
	
	public WebElement birthYear()

	{
		return birthYear;
	}
	
	public WebElement submit()

	{
		return submit;
	}
}
