package qaclickacademy;

import org.testng.annotations.Test;
//rahulonlinetutor@gmail.com
public class RESTAPITest {

	@Test
	public void postJira()
	{
		System.out.println("postJira");
	}
	
	@Test
	public void deleteTwitter()
	{
		System.out.println("deleteTwitter");	
	}
}
