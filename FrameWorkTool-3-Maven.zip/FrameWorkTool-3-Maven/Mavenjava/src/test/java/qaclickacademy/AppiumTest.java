package qaclickacademy;

import org.testng.annotations.Test;

public class AppiumTest {
	@Test
	public void NativeAPpAndroid()
	{
		System.out.println("NativeAPpAndroid");
	}
	
	@Test
	public void IOSApps()
	{
		System.out.println("IOSApps");	
	}
}
