/// <reference types="Cypress" />
 
describe('My CheckBox Test Suite', function() 
{
 
it('My CheckBox Test Case',function() {
 
 
cy.visit("https://rahulshettyacademy.com/AutomationPractice")

cy.get('[value="radio3"]').check().should('be.checked')
}  )
}  )