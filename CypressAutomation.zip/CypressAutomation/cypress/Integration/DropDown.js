/// <reference types="Cypress" />
 
describe('My Dropdown Test Suite', function() 
{
 
it('My Dropdown Test Case',function() {
 
 
cy.visit("https://rahulshettyacademy.com/AutomationPractice")

// Static Dropdown 
cy.get('select').select('option2').should('have.value','option2')

// Dynamic Dropdown 
cy.get('#autocomplete').type('ind')
cy.get('.ui-menu-item div').each(($el,index,$list) => {

    if ($el.text()==="India")
    {
        cy.wrap($el).click()
    }
})

cy.get('#autocomplete').should('have.value','India')

})
})