package com.banking.utils;

public class BaseClass {
	
	

}
