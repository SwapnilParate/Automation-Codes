package stepDefinations;

import org.junit.runner.RunWith;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)

public class stepDefination {

	@Given("^User is on landing page$")
	public void user_is_on_landing_page() throws Throwable {

		System.out.println("Hello");

	}

	@When("^User enters the valid username and password$")
	public void user_enters_the_valid_username_and_password() throws Throwable {

		System.out.println("Hello");
	}

	@Then("^User is able to login successfully$")
	public void user_is_able_to_login_successfully() throws Throwable {

		System.out.println("Hello");
	}

	@And("^Can see the landing page$")
	public void can_see_the_landing_page() throws Throwable {

		System.out.println("Hello");
	}

}
