import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.testng.annotations.Test;

public class Test1 {

//	@Test
	public void Regular() {

		ArrayList<String> names = new ArrayList();
		names.add("Swapnil");
		names.add("Devi");
		names.add("Swarag");
		names.add("Tushar");
		names.add("Shyam");
		names.add("Sanket");
		names.add("Payal");
		int count = 0;

		for (int i = 0; i < names.size(); i++) {
			String actual = names.get(i);
			if (actual.startsWith("S")) {
				count++;
			}
		}
		System.out.println(count);
	}

	// @Test
	public void StreamFilter() {

		ArrayList<String> names = new ArrayList();
		names.add("Swapnil");
		names.add("Devi");
		names.add("Swarag");
		names.add("Tushar");
		names.add("Shyam");
		names.add("Sanket");
		names.add("Payal");

		Long count = names.stream().filter(a -> a.startsWith("S")).count();
		System.out.println(count);

	}

	
}