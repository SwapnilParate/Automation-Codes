import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.testng.annotations.Test;

public class StreamMap {

	@Test
	public void Streammap() {

		// Print names ending with letter "L"
		Stream.of("Swapnil", "Neel", "Ramel", "Java", "Seema").filter(b -> b.endsWith("l"))
				.forEach(b -> System.out.println(b));

		// Limit the no of results
		Stream.of("Swapnil", "Neel", "Ramel", "Java", "Seema").filter(a -> a.length() > 4).limit(2)
				.forEach(a -> System.out.println(a));

		// Print name ending with letter "A" in UpperCase
		Stream.of("Swapnil", "Neel", "Ramel", "Java", "Seema").filter(c -> c.endsWith("a")).map(c -> c.toUpperCase())
				.forEach(c -> System.out.println(c));

		// Convert array to arraylist

		List<String> values = Arrays.asList("Azin", "Abin", "Ayin", "Den");
		values.stream().filter(e -> e.startsWith("A")).sorted().map(e -> e.toLowerCase())
				.forEach(e -> System.out.println(e));
	}
}

