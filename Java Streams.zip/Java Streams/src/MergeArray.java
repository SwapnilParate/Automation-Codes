import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.testng.Assert;
import org.testng.annotations.Test;

public class MergeArray {
	
	//@Test
	public void Mergearray () {
		
		// 1st Way of merging two arraylist 
		
		ArrayList<String> names1 = new ArrayList();
		names1.add("Adam");
		names1.add("Hulan");
		names1.add("Juli");
		
		System.out.println(names1);
		
		ArrayList<String> names2 = new ArrayList();
		names2.add("Ram");
		names2.add("Jam");
		names2.add("Gam");
		
		System.out.println(names2);
		
		Stream<String> mergedArray = Stream.concat(names1.stream(), names2.stream());
		boolean flag = mergedArray.anyMatch(s->s.equalsIgnoreCase("Ram"));
		System.out.println(flag);
		Assert.assertTrue(flag);
		
		
	}

	@Test
	public void Two () {
		
		ArrayList<String> names1 = new ArrayList();
		names1.add("Adam");
		names1.add("Hulan");
		names1.add("Juli");
		
		System.out.println(names1);
		
		List <String> names2 = Arrays.asList("Jam","Ram");
		System.out.println(names2);
		
		Stream<String> newList = Stream.concat(names1.stream(), names2.stream());
		boolean flag = newList.anyMatch(s->s.equalsIgnoreCase("Jam"));
		System.out.println(flag);
		Assert.assertTrue(flag);
		
		
	}
}
