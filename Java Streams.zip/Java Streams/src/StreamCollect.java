import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.testng.annotations.Test;

public class StreamCollect {

	//@Test
	public void collect () {
		
	List<String> ls = 	Stream.of("Swapnil", "Neel", "Ramel", "Java", "Seema").filter(s->s.startsWith("S")).collect(Collectors.toList());
	System.out.println(ls.get(0));
	}
	
	@Test
	public void collect1 () {
		
		List<Integer> num = Arrays.asList(1,9,2,43,4,5,6,6,6,7,8,4,3,3);
		
		// Print only unique numbers from the list 
		num.stream().distinct().forEach(a-> System.out.println(a));
		
		// Print in sorted order and print 3rd element in it
		num.stream().distinct().sorted().forEach(s-> System.out.println(s));
		List<Integer> li = num.stream().distinct().sorted().collect(Collectors.toList());
		System.out.println(li.get(2));
	}
}
