import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class WebTableStream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Swapnil\\eclipse-workspace\\PracticeCode\\Drivers\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
		
		// click on table 
		driver.findElement(By.xpath("//tr//th[1]")).click();
		
		// capture webements in list 
		List<WebElement> listelement = driver.findElements(By.xpath("//tr//td[1]"));
		
		// get text of each element 
		List<String> originallist = listelement.stream().map(s->s.getText()).collect(Collectors.toList());
		System.out.println(originallist);
		
		// sort list in the order 
		List<String> sortedlist = originallist.stream().sorted().collect(Collectors.toList());

		// compare both list and print the result 
		Assert.assertTrue(originallist.equals(sortedlist));
	}

}
