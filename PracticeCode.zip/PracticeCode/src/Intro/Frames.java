package Intro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Frames {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Swapnil\\eclipse-workspace\\PracticeCode\\Drivers\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.get("http://the-internet.herokuapp.com/");
		driver.findElement(By.xpath("//a[normalize-space()='Frames']")).click();
		driver.findElement(By.xpath("//a[normalize-space()='iFrame']")).click();
		
		// Access the Iframe to perform actions 
		// Identify iframe by the frame webelement 
		
		driver.switchTo().frame(driver.findElement(By.id("mce_0_ifr")));
		
		// Count no of iframes in the webpage 
		
		//System.out.println(driver.findElement(By.tagName("iframe")).getSize());
		
		driver.findElement(By.xpath("//p[normalize-space()='Your content goes here.']")).sendKeys("iframes practice");


	}

}
