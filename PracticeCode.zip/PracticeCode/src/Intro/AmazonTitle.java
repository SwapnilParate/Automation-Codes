package Intro;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonTitle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Swapnil\\eclipse-workspace\\PracticeCode\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in/");
		
		// Count of all links in Page
		System.out.println(driver.findElements(By.tagName("a")).size());
		
		// Count of Footer Links 
		WebElement footerlinks = driver.findElement(By.xpath("//div[@id='navFooter']"));
		System.out.println(footerlinks.findElements(By.tagName("a")).size());
		
		WebElement columnlink = driver.findElement(By.xpath("//body/div[@id='a-page']/div[@id='navFooter']/div[@role='presentation']/div[@class='navFooterVerticalRow navAccessibility']/div[1]"));
		System.out.println(columnlink.findElements(By.tagName("a")).size());
		
		// Click all links in column one by one 
		
		for (int i=0;i<columnlink.findElements(By.tagName("a")).size();i++) {
			
			String clickonlinkTab = Keys.chord(Keys.CONTROL, Keys.ENTER);
			columnlink.findElements(By.tagName("a")).get(i).sendKeys(clickonlinkTab);
			
		}
		Set<String> abc = driver.getWindowHandles();// 4
		Iterator<String> it = abc.iterator();
		while (it.hasNext()) {
			driver.switchTo().window(it.next());
			System.out.println(driver.getTitle());
		}
	}
}
