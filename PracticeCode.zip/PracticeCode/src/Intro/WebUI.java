package Intro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebUI {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Swapnil\\eclipse-workspace\\PracticeCode\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://demoqa.com/");
		Thread.sleep(3000);
		driver.manage().window().maximize();

		driver.findElement(By.xpath("//*[name()='path' and contains(@d,'M16 132h41')]")).click();
		// Text Box
		String userName = "Swapnil";
		String email = "Dummy@gmail.com";
		String address = "Automation Testing Practice in Web UI";
		String paddress = "Automation Testing Practice in Web UI";
		
		driver.findElement(By.xpath("//span[normalize-space()='Text Box']")).click();
		driver.findElement(By.xpath("//input[@id='userName']")).sendKeys(userName);
		driver.findElement(By.xpath("//input[@id='userEmail']")).sendKeys(email);
		driver.findElement(By.xpath("//textarea[@id='currentAddress']")).sendKeys(address);
		driver.findElement(By.xpath("//textarea[@id='permanentAddress']")).sendKeys(paddress);
		//driver.findElement(By.xpath("//*[name()='path' and contains(@d,'M0,0l15,0l')]")).click();
		driver.findElement(By.id("submit")).click();
		
	}

}
