package Intro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class HealthCare {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Swapnil\\eclipse-workspace\\PracticeCode\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://katalon-demo-cura.herokuapp.com/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//a[@id='btn-make-appointment']")).click();
		driver.findElement(By.xpath("//input[@id='txt-username']")).sendKeys("John Doe");
		driver.findElement(By.xpath("//input[@id='txt-password']")).sendKeys("ThisIsNotAPassword");
		driver.findElement(By.xpath("//button[@id='btn-login']")).click();
		
		WebElement dropDownValue = driver.findElement(By.xpath("//select[@id='combo_facility']"));
		Select dropdown = new Select(dropDownValue);
		dropdown.selectByVisibleText("Seoul CURA Healthcare Center");
		System.out.println(dropdown.getFirstSelectedOption().getText());
		
		Assert.assertFalse(driver.findElement(By.xpath("//input[@id='chk_hospotal_readmission']")).isSelected());
		driver.findElement(By.xpath("//input[@id='chk_hospotal_readmission']")).click();
		Assert.assertTrue(driver.findElement(By.xpath("//input[@id='chk_hospotal_readmission']")).isSelected());
		
		Assert.assertFalse(driver.findElement(By.xpath("//input[@id='radio_program_medicaid']")).isSelected());
		driver.findElement(By.xpath("//input[@id='radio_program_medicaid']")).click();
		Assert.assertTrue(driver.findElement(By.xpath("//input[@id='radio_program_medicaid']")).isSelected());
		
		driver.findElement(By.xpath("//span[@class='glyphicon glyphicon-calendar']")).click();
		driver.findElement(By.xpath("//td[normalize-space()='13']")).click();
		driver.findElement(By.xpath("//textarea[@id='txt_comment']")).sendKeys("Hi This is me trying to learn Automation Testing");
		driver.findElement(By.xpath("//button[@id='btn-book-appointment']")).click();
		
		String confirmationText = driver.findElement(By.xpath("//h2[normalize-space()='Appointment Confirmation']")).getText();
		System.out.println(confirmationText);
		driver.quit();
	}

}
