package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPage {
	
	public WebDriver driver ;
	
	By noThanks = By.xpath("//button[normalize-space()='NO THANKS']");
	By loginButton = By.cssSelector("a[href*='sign_in'");
	By title = By.cssSelector("div[class='text-center'] h2");
	By contactTab = By.xpath("//a[normalize-space()='Contact']");
	
	public LandingPage (WebDriver driver)
	{
		this.driver=driver;
	}
	
	public WebElement noThanks ()
	{
		return driver.findElement(noThanks);
	}
	
	public WebElement loginPage ()
	{
		return driver.findElement(loginButton);
	}
	
	public WebElement getTitle ()
	{
		return driver.findElement(title);
	}
	
	public WebElement getContactTab ()
	{
		return driver.findElement(contactTab);
	}

}
