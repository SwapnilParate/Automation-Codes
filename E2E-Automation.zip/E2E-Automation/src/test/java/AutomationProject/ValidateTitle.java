package AutomationProject;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pageObject.LandingPage;
import resources.Base;

public class ValidateTitle extends Base {

	@BeforeTest
	public void initialization() throws IOException {
		driver = initializeBrowser();
		driver.get(prop.getProperty("url"));
	}

	@Test
	public void titleValidation() throws IOException {

		LandingPage lp = new LandingPage(driver);
		lp.noThanks().click();
		Assert.assertEquals(lp.getTitle().getText(), "FEATURED COURSES");
		Assert.assertTrue(lp.getContactTab().isDisplayed());
	}

	@AfterTest
	public void tearDown() {
		driver.close();
	}
}
