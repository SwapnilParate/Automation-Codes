package AutomationProject;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageObject.LandingPage;
import pageObject.LoginPage;
import resources.Base;

public class HomePage extends Base {

	@Test(dataProvider = "getData")
	public void basePageNavigation(String username, String password) throws IOException {
		
		driver = initializeBrowser();
		driver.get(prop.getProperty("url"));
		LandingPage lp = new LandingPage(driver);
		lp.noThanks().click();
		lp.loginPage().click();
		LoginPage login = new LoginPage(driver);
		login.userEmail().sendKeys(username);
		login.userPassword().sendKeys(password);
		login.submitButton().click();
		
		driver.close();

	}

	@DataProvider

	public Object[][] getData() {
		Object[][] data = new Object[2][2];

		// 1st set of data
		data[0][0] = "firstuser@gmail.com";
		data[0][1] = "123456";

		// 2nd set of data
		data[1][0] = "seconduser@gmail.com";
		data[1][1] = "567845";

		return data;
	}

}
